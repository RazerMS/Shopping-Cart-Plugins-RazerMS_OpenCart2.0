<?php
/**
 * Razer Merchant Services OpenCart Plugin
 *
 * @package Payment Gateway
 * @author Razer Merchant Services Technical Team <technical-sa@razer.com>
 * @version 3.0
 */

// Text
$_['text_title'] = 'Razer Merchant Services';
